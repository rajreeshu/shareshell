    
        <script src="<?=base_url();?>assets/js/modernizr-2.6.2.min.js"></script>

        <script src="<?=base_url();?>assets/js/jquery-1.10.2.min.js"></script>
        
    <script src="<?=base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>


        <script src="<?=base_url();?>assets/js/bootstrap-select.min.js"></script>
        <script src="<?=base_url();?>assets/js/bootstrap-hover-dropdown.js"></script>

        <script src="<?=base_url();?>assets/js/easypiechart.min.js"></script>
        <script src="<?=base_url();?>assets/js/jquery.easypiechart.min.js"></script>

        <script src="<?=base_url();?>assets/js/owl.carousel.min.js"></script>        

        <script src="<?=base_url();?>assets/js/wow.js"></script>

        <script src="<?=base_url();?>assets/js/icheck.min.js"></script>
        <script src="<?=base_url();?>assets/js/price-range.js?v=1.1"></script>

        <script src="<?=base_url();?>assets/js/main.js?v=1.1"></script>
        
        <script src="<?=base_url();?>assets/js/myjs.js?v=3.6"></script>
