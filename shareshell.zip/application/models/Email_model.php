<?php

class Email_model extends CI_Model{

	public function sendEmail($email,$content){

		

		return 0;
	}

}


?> 