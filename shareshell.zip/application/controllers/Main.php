<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller { 

	public function index(){

		$this->load->view('website/home');	
	} 

	public function properties(){ 

		$this->load->view('website/properties');
	}

	public function property(){

		$this->load->view('website/property');
	}

	public function contact(){
		$this->load->view('website/contact');
	}

	public function faq(){
		$this->load->view('website/faq');
	}

	public function aboutus(){
		$this->load->view('website/about_us');
	}

	public function testimonial(){
		$this->load->view('website/testimonial_page');
	}

	public function privacypolicy(){
		$this->load->view('website/privacy_policy');
	}

	public function termsconditions(){
		$this->load->view('website/terms_conditions');
	}


	public function Submit_property(){
		if($this->security->xss_clean($this->session->userdata('user_id_shareshell'))){
			$this->load->view('website/property_submit');	
		}else{
			redirect('main/log_user');
		}
		
	}

	public function property_submited(){
		$this->load->view('website/property_submited');
	}

	public function log_user(){

		if(!$this->security->xss_clean($this->session->userdata('user_id_shareshell'))){
			$this->load->view('website/login_signup');
		}else{
			redirect('account');
		}

		
	}
	public function signup_detail(){
		
		$this->load->view('website/signup_second');
	}
	public function account_created(){
		if($this->security->xss_clean($this->session->userdata('otp_verify_signup_shareshell'))){
			$this->load->view('website/account_created');
		}else{
			redirect("main/log_user");
		}
		
	}

	public function account(){
		if($this->security->xss_clean($this->session->userdata('user_id_shareshell'))){
			$this->load->view('website/useraccount');	
		}else{
			redirect('main/log_user');
		}
		
	}

	public function changePassword(){
		if($this->security->xss_clean($this->session->userdata('user_id_shareshell'))){
			$this->load->view('website/change_password');	
		}else{
			redirect('main/log_user');
		}
	}

	public function myProperties(){
		if($this->security->xss_clean($this->session->userdata('user_id_shareshell'))){
			$this->load->view('website/my_properties');
		}else{
			redirect('main/log_user');
		}
	}

	public function forgetpassword(){
		if(!$this->security->xss_clean($this->session->userdata('user_id_shareshell'))){
			$this->load->view('website/forget_password');
		}else{
			redirect('main/account');
		}
	}



	public function my404(){
		$this->load->view('website/404');
	}

}
