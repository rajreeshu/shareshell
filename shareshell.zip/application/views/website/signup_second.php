<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
        <title>SHARESHELL| Home page</title>
        <meta name="shareshell" content="Making rental easy">
        <meta name="author" content="Kimarotec">
        <meta name="keyword" content="html5, css, bootstrap, property, real-estate theme , bootstrap template">
        <meta name="viewport" content="width=device-width, initial-scale=1">

 <!--        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700,800' rel='stylesheet' type='text/css'>
 -->
        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
<!--         <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
        <link rel="icon" href="favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="assets/css/normalize.css">
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/fontello.css">
        <link href="assets/fonts/icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet">
        <link href="assets/fonts/icon-7-stroke/css/helper.css" rel="stylesheet">
        <link href="assets/css/animate.css" rel="stylesheet" media="screen">
        <link rel="stylesheet" href="assets/css/bootstrap-select.min.css"> 
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/icheck.min_all.css">
        <link rel="stylesheet" href="assets/css/price-range.css">
        <link rel="stylesheet" href="assets/css/owl.carousel.css">  
        <link rel="stylesheet" href="assets/css/owl.theme.css">
        <link rel="stylesheet" href="assets/css/owl.transitions.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="assets/css/responsive.css"> -->
        <?php
    $this->load->view('website/link_import');
    $this->load->view('website/header');
?>
    </head>
    <body>


        <div class="page-head"> 
            <div class="container">
                <div class="row">
                    <div class="page-head-content">
                        <h1 class="page-title">Hello : <span class="orange strong">YOUR NAME</span></h1>               
                    </div>
                </div>
            </div>
        </div>
        <!-- End page header --> 

        <!-- property area -->
        <div class="content-area user-profiel" style="background-color: #FCFCFC;">&nbsp;
            <div class="container">   
                <div class="row">
                    <div class="col-sm-10 col-sm-offset-1 profiel-container">

                        <form enctype="multipart/form-data" method="post" id="form_field">
                            
                            <div class="profiel-header">
                                <h3>
                                    <b>BUILD</b> YOUR PROFILE <br>
                                    <small>This information will let us know more about you.</small>
                                </h3>
                                <hr>
                            </div>

                            <div class="clear">
                                <div class="col-sm-3 col-sm-offset-1">
                                    <div class="picture-container">
                                        <div class="picture">
                                            <img src="" style=" height: 100%;object-fit: cover;" title="" id="show_image_field" />
                                            <div style=" margin-top:70px;"><b>Click and Upload</b></div>
                                            <input type="file" id="image_field" name="image_field">
                                        </div>
                                        <h6>Choose Picture</h6>
                                    </div>
                                </div>

                                <div class="col-sm-3 padding-top-25">
                                    <div class="form-group">
                                        <label>Username </label>&nbsp
                                        <b><span class="text-danger mr-1" id="signup_username_error"></span></b>
                                        <input name="username_field" type="text" class="form-control" placeholder="myusername" id="username_field">
                                    </div> 
                                    <div class="form-group">
                                        <label>First Name <small>(required)</small></label>
                                        <b><span class="text-danger mr-1" id="signup_first_name_error"></span></b>
                                        <input name="first_name_field" type="text" class="form-control" placeholder="first name" id="first_name_field">
                                    </div>
                                    <div class="form-group">
                                        <label>Last Name </label>
                                        <b><span class="text-danger mr-1" id="signup_last_name_error"></span></b>
                                        <input name="last_name_field" type="text" class="form-control" placeholder="last name" id="last_name_field">
                                    </div> 
                                    
                                </div>
                                <div class="col-sm-3 padding-top-25">
                                    <div class="form-group">
                                        <label>Email <small>(required)</small></label>
                                        <b><span class="text-danger mr-1" id="signup_email_error"></span></b>
                                        <input name="email_field" type="text" class="form-control" placeholder="abc123@xyz.com" id="email_field">
                                    </div>
                                    <div class="form-group">
                                        <label>Password : <small>(required)</small></label>
                                        <b><span class="text-danger mr-1" id="signup_password_error"></span></b>
                                        <input type="password" name="password_field" class="form-control" placeholder="******" id="password_field">
                                    </div>
                                </div>  

                            </div>

                            <div class="clear">
                                <br>
                                <hr>
                                <br>
                                <div class="col-sm-5 col-sm-offset-1">
                                    
                                    <div class="form-group">
                                        <label>Website :</label>
                                        <b><span class="text-danger mr-1" id="website_username_error"></span></b>
                                        <input name="website_field" type="text" class="form-control" placeholder="https://yoursite.com/" id="website_field">
                                    </div>
                                    <div class="form-group">
                                        <b><span class="text-danger mr-1" id="phone_username_error"></span></b>
                                        <label>Phone :</label>
                                        <input name="phone_field" type="number" class="form-control" placeholder="+91 9090909090" id="phone_field">
                                    </div>

                                </div>  

                                <div class="col-sm-5">
                                    <div class="form-group">
                                        <label>Facebook :</label>
                                        <b><span class="text-danger mr-1" id="signup_facebook_error"></span></b>
                                        <input name="facebook_field" type="text" class="form-control" placeholder="https://facebook.com/user" id="fb_field">
                                    </div>
                                    <div class="form-group">
                                        <label>Twitter :</label>
                                        <b><span class="text-danger mr-1" id="signup_twitter_error"></span></b>
                                        <input name="twitter_field" type="text" class="form-control" placeholder="https://Twitter.com/@user" id="twitter_field">
                                    </div>
                                </div>
 
                            </div>
                            <div class="col-sm-5 col-sm-offset-1">
                                <br>
                                <input type='submit' class='btn btn-finish btn-primary' name='field_submit' value='Finish' id="field_submit" >
                            </div>
                            <br>
                    </form>

                </div>
            </div><!-- end row -->

        </div>
    </div>



<!--         <script src="assets/js/vendor/modernizr-2.6.2.min.js"></script>
        <script src="assets/js//jquery-1.10.2.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/bootstrap-select.min.js"></script>
        <script src="assets/js/bootstrap-hover-dropdown.js"></script>
        <script src="assets/js/easypiechart.min.js"></script>
        <script src="assets/js/jquery.easypiechart.min.js"></script>
        <script src="assets/js/owl.carousel.min.js"></script>
        <script src="assets/js/wow.js"></script>
        <script src="assets/js/icheck.min.js"></script>

        <script src="assets/js/price-range.js"></script> 
        <script src="assets/js/jquery.bootstrap.wizard.js" type="text/javascript"></script>
        <script src="assets/js/jquery.validate.min.js"></script>
        <script src="assets/js/wizard.js"></script>

        <script src="assets/js/main.js"></script> -->
<?php
    $this->load->view('website/footer');

    $this->load->view('website/js_import');

    $session_username="";
    if(isset($_GET['u'])){
        $session_username=$_GET['u'];
    }

    

    // $temp_session=$this->session->flashdata('item'); 


?>

<script type="text/javascript">  

var key="<?php echo $this->security->get_csrf_hash(); ?>"; 
    
    function isEmail(email) {
      var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
      return regex.test(email);
    }

    function isURL(str) {
      var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
        '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name
        '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
        '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
        '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
        '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
      return !!pattern.test(str);
}

    function blur_field(fieldName){
        $(fieldName).css('background', '#eeeeee');
        $(fieldName).focus(function() {
            $(fieldName).blur();
        });
    }

    function validate_data(datatype,userdata){
        var result;
        $.ajax({
            url:"<?=base_url('main_helper/signup_validate_data');?>",
            type:"POST",
            async:false,
            data:{
                "<?php echo $this->security->get_csrf_token_name();?>":key,
                datatype:datatype,
                data:userdata
                
                        
                },
                dataType:"json",
                success:function(data){
                    key=data.key;
                    // console.log(data);
                    result=data.data;
                },
                error:function(data){
                    console.log(data);
                    // result=data;
                }
        });
        return result;  
    }   

    var session_username="<?=$session_username;?>";
    var session_email="<?=$_GET['e'];?>";
    var session_password="<?=$_GET['p'];?>";

    if(isEmail(session_email)==false||session_password==""||(session_username!=""&&session_username.length<6)){
        window.location.href = "<?=base_url('main/log_user');?>"; 
        // console.log("red");
    }

    if(session_username!=""){
        $("#username_field").val(session_username);
        blur_field("#username_field");
           
    }

    $("#email_field").val(session_email);
    blur_field("#email_field");
    var emai_unique=validate_data('email',session_email);
    if(emai_unique==1){
        window.location.href = "<?=base_url('main/log_user');?>"; 
    }  
    
    $("#password_field").val(session_password);
    blur_field("#password_field");

function field_error_css(fieldName){
    $(fieldName).css('border','1px solid red');
    // $(fieldName).css('background','#fd94b4');
}

function field_error_cssRemove(fieldName){
    $(fieldName).css('border','1px solid #DADADA');
}


    function previewFile(){
        var file = $("#image_field").get(0).files[0];
 
        if(file){
            var reader = new FileReader();
 
            reader.onload = function(){
                $("#show_image_field").attr("src", reader.result);
            }
 
            reader.readAsDataURL(file);
        }
    }

    $("#image_field").change(function() {
        previewFile();
        console.log("chagne");
    });

var formFieldData_check=1; 

$("#form_field").submit(function(event) {
    event.preventDefault();

    formFieldData_check=1;
    var isUrl_var=isURL($("#website_field").val());
    var new_website_field=$("#website_field").val();       

    if($("#username_field").val()!=""&&$("#username_field").val().length<6){
        // formFieldData_check=0;
        formFieldData_check=0;
        field_error_css("#username_field");
        $("#signup_username_error").html("Too Small");
    }else{
        result=validate_data('username',$("#username_field").val());
        if(result>0&&$("#username_field").val()!=""){
            $("#signup_username_error").html('Unavailable');
            formFieldData_check=0;
            field_error_css("#username_field");

        }else{
            field_error_cssRemove('#username_field'); 
            $("#signup_username_error").html('');
        }        
    }

    if($("#first_name_field").val()==""){
        formFieldData_check=0;
        field_error_css("#first_name_field");
        console.log("first name 0");
    }else{
        field_error_cssRemove('#first_name_field');
        
    }

    if(new_website_field==""||isUrl_var==true){
        if(new_website_field!=""&&new_website_field.substring(0,4)!="http"){
            new_website_field="https://"+new_website_field;
        }
        
        field_error_cssRemove("#website_field");

    }else{
        formFieldData_check=0;
        field_error_css("#website_field");
        console.log("website 0");
    }

    var formData = new FormData(this);
    formData.append("<?= $this->security->get_csrf_token_name();?>",key);
    formData.append('website_field_new',new_website_field);
    
    var image_field_check=$("#image_field").val();
    formData.append('image_field_check',image_field_check);

    // for (var pair of formData.entries()){
    //     console.log(pair[0]+ ': '+ pair[1]); 
    // }

    if(formFieldData_check==0){
        // formData.delete('website_field');
        console.log(formFieldData_check);
    }else{
        $.ajax({
            type:"POST",
            url:"<?=base_url('main_helper/submit_signup_data');?>",
            async:false,
            data: formData,
            dataType:"json",
            processData: false,
            contentType: false,
            success:function(data){
                key=data.key;

                if(data.data==true){
                    window.location.href = "<?=base_url('main/account_created');?>"; 
                }else{
                    alert("Something Went Wrong.");
                }

                console.log(data);
                    
            },
            error:function(data){
                console.log(data);
                    // result=data;
            }
        });
    }


});

</script>

</body>
</html>