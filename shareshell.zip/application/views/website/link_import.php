
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700,800' rel='stylesheet' type='text/css'>

        <!-- Place favicon.ico  the root directory -->
        <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
        <link rel="icon" href="favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="<?=base_url();?>assets/css/normalize.css">
        <link rel="stylesheet" href="<?=base_url();?>assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?=base_url();?>assets/css/fontello.css">
        <link href="<?=base_url();?>assets/fonts/icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet">
        <link href="<?=base_url();?>assets/fonts/icon-7-stroke/css/helper.css" rel="stylesheet">
        <link href="<?=base_url();?>assets/css/animate.css" rel="stylesheet" media="screen">
        <link rel="stylesheet" href="<?=base_url();?>assets/css/bootstrap-select.min.css"> 
        <link rel="stylesheet" href="<?=base_url();?>assets/bootstrap/css/bootstrap.min.css">
        
         <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script> -->


        <link rel="stylesheet" href="<?=base_url();?>assets/css/icheck.min_all.css">
        <link rel="stylesheet" href="<?=base_url();?>assets/css/price-range.css">
        <link rel="stylesheet" href="<?=base_url();?>assets/css/owl.carousel.css">  
        <link rel="stylesheet" href="<?=base_url();?>assets/css/owl.theme.css">
        <link rel="stylesheet" href="<?=base_url();?>assets/css/owl.transitions.css">
        <link rel="stylesheet" href="<?=base_url();?>assets/css/style.css">
        <link rel="stylesheet" href="<?=base_url();?>assets/css/responsive.css">