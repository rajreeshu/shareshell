    
        <script src="<?=base_url();?>assets/js/modernizr-2.6.2.min.js"></script>

        <script src="<?=base_url();?>assets/js/jquery-1.10.2.min.js"></script>
        
        <!-- <script src="bootstrap/js/bootstrap.min.js"></script> -->

        <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script> -->
        <script src="<?=base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>


        <script src="<?=base_url();?>assets/js/bootstrap-select.min.js"></script>
        <script src="<?=base_url();?>assets/js/bootstrap-hover-dropdown.js"></script>

        <script src="<?=base_url();?>assets/js/easypiechart.min.js"></script>
        <script src="<?=base_url();?>assets/js/jquery.easypiechart.min.js"></script>

        <script src="<?=base_url();?>assets/js/owl.carousel.min.js"></script>        

        <script src="<?=base_url();?>assets/js/wow.js"></script>

        <script src="<?=base_url();?>assets/js/icheck.min.js"></script>
        <script src="<?=base_url();?>assets/js/price-range.js"></script>

        <script src="<?=base_url();?>assets/js/main.js"></script>
        
        <script src="<?=base_url();?>assets/js/myjs.js"></script>
<!-- <script type="text/javascript">
    
    $("#aboutus_cover").click(function(){
        window.location.href = "<?=base_url('main/aboutus');?>";
    })

</script> -->